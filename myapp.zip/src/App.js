import * as React from "react"
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom"
import './App.css';
import Nav from './Component/Navbar';
import Main from './Component/Main';
import Footer from './Component/Footer';
import About from "./Component/About";


function App() {
  return (
    <div className="App">
      <Router>
            <Nav/>
            <Main/>
            <Routes>
                <Route index element ={<Main/>}/>
                <Route path="about" element ={<About/>}/>
                <Route path="footer" element ={<Footer/>}/>
            </Routes>
        </Router>
    </div>
  );
}

export default App;
